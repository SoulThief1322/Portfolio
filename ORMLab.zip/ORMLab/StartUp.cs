﻿using Microsoft.EntityFrameworkCore;
using ORMLab.Data;
using SoftUni.Models;

Console.WriteLine(SoftUniContext.FindEmployeesWithJobTitle(new SoftUniContext()));



SoftUniContext.CreateNewProject(new SoftUniContext());
SoftUniContext.UpdateFirstEmployee(new SoftUniContext());

SoftUniContext.DeleteFirstProject(new SoftUniContext());

SoftUniContext.UpdateAddresses(new SoftUniContext());
