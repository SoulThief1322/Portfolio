﻿using SoftUni.Data;
using System;
using System.Linq;
using System.Text;
namespace SoftUni
{
    public class StartUp
    {
        static void Main()
        {
            SoftUniContext softUniContext = new SoftUniContext();
            Console.WriteLine(GetEmployeesInPeriod(softUniContext));
        }

        //Problem 01
        public static string GetEmployeesFullInformation(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees.Select(x => new {x.EmployeeId, x.FirstName, x.LastName, x.MiddleName, x.JobTitle, x.Salary}).OrderBy(e => e.EmployeeId).ToList();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName}" + $"{employee.JobTitle} {employee.Salary:F2}");
            }
            return sb.ToString().Trim();
        }

        //Problem 02
        public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees.Select(x => new { x.FirstName, x.Salary }).Where(e => e.Salary > 50000).OrderBy(e => e.FirstName).ToList();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }
            return sb.ToString().Trim();
        }

        //Problem 03
        public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees.Select(x => new { x.FirstName, x.Salary,x.LastName, x.Department }).Where(e => e.Department.Name == "Research and Development").OrderBy(e => e.Salary).ThenByDescending(e => e.FirstName).ToList();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} from {employee.Department.Name} - ${employee.Salary:F2}");
            }
            return sb.ToString().Trim();
        }

        //Problem 04
        public static string AddNewAddressToEmployee(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees.Select(x => new { x.FirstName, x.Salary }).Where(e => e.Salary > 50000).OrderBy(e => e.FirstName).ToList();
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} - {employee.Salary:F2}");
            }
            return sb.ToString().Trim();
        }

        //Problem 05
        public static string GetEmployeesInPeriod(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            var employees = context.Employees.Where(e => e.EmployeesProjects.Any(ep => ep.Project.StartDate.Year >= 2001 && ep.Project.StartDate.Year <= 2003))
                .Select(e => new {e.FirstName, e.LastName, ManagerLastName = e.Manager.LastName, ManagerFirstName = e.Manager.FirstName, Projects = e.EmployeesProjects.Select(b => new { ProjectName = b.Project.Name, ProjectStartDate = b.Project.StartDate, ProjectEndDate = b.Project.EndDate }) }).Take(10);
            foreach (var employee in employees)
            {
                sb.AppendLine($"{employee.FirstName} {employee.LastName} - Manager: {employee.ManagerFirstName} {employee.ManagerLastName}");
                foreach(var project in employee.Projects)
                {
                    var endDate = project.ProjectEndDate.HasValue ? project.ProjectEndDate.Value.ToString("M/d/yyyy h:mm:ss tt") : "not finished";
                    sb.AppendLine($"--{project.ProjectName} - {project.ProjectStartDate.ToString("M/d/yyyy h:mm:ss tt")} - {endDate}");
                }
            }
            return sb.ToString().TrimEnd();
        }

        //Problem 06
        public static string GetAddressesByTown(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Problem 07
        public static string GetEmployee147(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Problem 08
        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Problem 09
        public static string GetLatestProjects(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Problem 10
        public static string IncreaseSalaries(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Problem 11
        public static string GetEmployeesByFirstNameStartingWithSa(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Problem 12
        public static string DeleteProjectById(SoftUniContext context)
        {
            StringBuilder sb = new StringBuilder();
            return sb.ToString().Trim();
        }

        //Probem 13
        public static string RemoveTown(SoftUniContext context)
        {
            return null;
            //return $"{addressesCount} addresses in Seattle were deleted";
        }
    }
}
