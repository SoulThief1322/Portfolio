﻿using ComputerStore.InterfacesAndClasses;
using System;
using System.Collections.Generic;
using System.Linq;
namespace ComputerStore
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            ILaptop traditionalLaptop;
            HybridLaptop hybridLaptop;
			List<ILaptop> list = new List<ILaptop>();
            string[] input = Console.ReadLine().Split();
            while(input.Length > 1)
            {
                if (input[0] == "AddLaptop")
                {
                    if (input[1] == "TraditionalLaptop")
                    {
                        traditionalLaptop = new TraditionalLaptop(int.Parse(input[2]), input[3], decimal.Parse(input[4])); list.Add(traditionalLaptop); Console.WriteLine("5");
                    }
                    else
                    {
						hybridLaptop = new HybridLaptop(int.Parse(input[2]), input[3], decimal.Parse(input[4])); list.Add(hybridLaptop);
					}
                   
                }
                if (input[0] == "AddHardware")
                {
                    foreach(ILaptop laptop in list)
                    {
                        if(laptop.Id == int.Parse(input[1]))
                        {
                            Hardware hardware = new Hardware(int.Parse(input[2]), input[3], decimal.Parse(input[4]), double.Parse(input[5]), int.Parse(input[6]));
                            laptop.AddHardware(hardware);
                        }
                    }
                }
                input = Console.ReadLine().Split();
            }
            double performance = 0;
            foreach(ILaptop laptop  in list)
            {
                Console.WriteLine(laptop.ToString());
                Console.WriteLine();
            }
        }
    }
}
