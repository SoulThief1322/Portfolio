﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.InterfacesAndClasses
{
	public class Product : IProduct
	{
		private int id;
		public int Id
		{
			get { return id; }
			set { if (value <= 0) throw new ArgumentException("The id is not allowed to be zero or less."); this.id = value; }
		}

		public string Model { get; set; }

		public decimal Price { get; set; }

		public virtual double OverallPerformance { get; set; }

		

		public Product(int id, string model, decimal performance)
		{

		}
		public override string ToString()
		{
			return $"Overall performance: {OverallPerformance}. Price: {Price}: (Id {Id})";
		}
		
	}
}
