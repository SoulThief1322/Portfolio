﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.InterfacesAndClasses
{
	public class Hardware : Product, IHardware 
	{
		public Hardware(int id, string model, decimal price, double overallPerformance, int generation) : base(id, model, price)
		{
			this.Id = id;
			this.Model = model;
			this.Price = price;
			this.OverallPerformance = overallPerformance;
			this.Generation = generation;
		}

		public int Generation { get; set; }
		public override string ToString()
		{
			return $"Model: {Model} with: Overall performance: {OverallPerformance}. Price: {Price}: (Id {Id}) Generation: {Generation}";
		}
	}
}
