﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.InterfacesAndClasses
{
	public abstract class Laptop : Product, ILaptop
	{
		private double overall;
		private List<IHardware> allHardware = new List<IHardware>();
        public IReadOnlyCollection<IHardware> HardwareParts { get { return allHardware; } }
        public Laptop(int id, string model, decimal price)
			: base(id, model, price)
		{

		}

		public override double OverallPerformance { get { return base.OverallPerformance + allHardware.Average(x => x.OverallPerformance); } }
		
		public void AddHardware(IHardware hardwarePart)
		{
			if (allHardware.Any(x => x.Model.Split('-')[0] == hardwarePart.Model.Split('-')[0]))
			{
				throw new ArgumentException($"Hardware part with Id: {Id} is already added");
			}
			allHardware.Add(hardwarePart);
			
		}
		public override string ToString()
		{
			return   $"Model: {Model} with: " + base.ToString() + Environment.NewLine + Environment.NewLine
			+ $"Hardware ({HardwareParts.Count})" + Environment.NewLine + string.Join(Environment.NewLine, HardwareParts);

		}
	}
}
