﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerStore.InterfacesAndClasses
{
	public class TraditionalLaptop : Laptop, ILaptop
	{
		public TraditionalLaptop(int id, string model, decimal price) : base(id, model, price)
		{
			if(this.HardwareParts.Count > 0)
			{
                this.OverallPerformance = 20 + this.HardwareParts.Average(x => x.OverallPerformance);
            }
			else this.OverallPerformance = 20;
		}
	}
}
